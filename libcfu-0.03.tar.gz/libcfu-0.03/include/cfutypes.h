/* Creation date: 2005-07-30 16:44:11
 * Authors: Don
 * Change log:
 */

#ifndef _CFU_TYPES_H_
#define _CFU_TYPES_H_

#include <sys/types.h>

/* u_int is defined */

#endif
